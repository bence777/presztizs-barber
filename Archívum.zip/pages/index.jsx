import Head from 'next/head';
import { useState } from 'react';
import styles from '../styles/Home.module.css';
import HeroVideo from '../components/HeroVideo';
import BarberStack from '../components/BarberStack';
import LanguageSwitcher from '../components/LanguageSwitcher';
import { useLanguage } from '../components/LanguageProvider';
import SalonStory from '../components/SalonStory';
import TrustSection from '../components/TrustSection';
import BookingFooter from '../components/BookingFooter';

function DemetersLogo({ className }) {
  return (
    <svg
      className={className}
      viewBox="0 0 502 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label="DEMETERS"
    >
      <g
        stroke="currentColor"
        strokeWidth="5.5"
        strokeLinecap="square"
        strokeLinejoin="miter"
      >
        <path d="M 5 20 V 6 H 28 C 64 6 64 58 28 58 H 5 V 44" />
        <path d="M 70 6 H 117 M 70 32 H 117 M 70 58 H 117" />
        <path d="M 135 58 V 6 L 162 36 L 189 6 V 58" />
        <path d="M 207 6 H 254 M 207 32 H 254 M 207 58 H 254" />
        <path d="M 267 6 H 319 M 293 6 V 58" />
        <path d="M 332 6 H 379 M 332 32 H 379 M 332 58 H 379" />
        <path d="M 394 6 H 419 C 442 6 442 34 419 34 H 394 M 394 34 V 58 M 415 34 L 439 58" />
        <path d="M 495 14 C 485 2 455 2 454 18 C 453 29 467 30 478 33 C 489 36 499 40 497 48 C 493 63 466 62 452 51" />
      </g>
    </svg>
  );
}

export default function Home() {
  const { t } = useLanguage();
  const [bookingRequest, setBookingRequest] = useState(null);

  return (
    <>
      <Head>
        <title>DEMETERS | Barber Debrecen</title>

        <meta
          name="description"
          content={t(
            "DEMETERS — precíz vágások, karakteres stílus. Online időpontfoglalás Debrecenben."
          )}
        />

        <meta property="og:site_name" content="DEMETERS" />
        <meta property="og:title" content="DEMETERS | Barber Debrecen" />

        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              '@context': 'https://schema.org',
              '@type': 'HairSalon',
              name: 'DEMETERS',
              areaServed: {
                '@type': 'City',
                name: 'Debrecen',
              },
            }),
          }}
        />
      </Head>

      <main id="teteje" className={styles.site}>
        <header className={styles.header}>
          <a
            className={styles.brand}
            href="/"
            aria-label="DEMETERS – Főoldal"
          >
            <DemetersLogo className={styles.navLogo} />
          </a>

          <div className={styles.headerActions}>
            <nav aria-label={t("Fő navigáció")}>
              <a href="#szalon">{t("A SZALON")}</a>
              <a href="#csapat">{t("CSAPAT")}</a>

              <a
                className={styles.bookingNav}
                href="#foglalas"
              >
                {t("FOGLALÁS")}
              </a>
            </nav>

            <LanguageSwitcher />
          </div>
        </header>

        <section
          className={styles.hero}
          aria-labelledby="hero-title"
        >
          <HeroVideo />

          <div
            className={styles.portrait}
            aria-hidden="true"
          />

          <div
            className={styles.shade}
            aria-hidden="true"
          />

          <div className={styles.center}>
            <DemetersLogo className={styles.heroLogo} />

            <h1
              id="hero-title"
              className={styles.heroTitle}
            >
              {t("Prémium barber szalon Debrecenben")}
            </h1>
          </div>

          <div className={styles.bottomline}>
            <span>{t("GÖRGESS LEJJEBB")}</span>

            <a href="#foglalas">
              {t("IDŐPONTFOGLALÁS")}
            </a>
          </div>
        </section>

        <SalonStory />

        <BarberStack
          onBook={barber =>
            setBookingRequest({
              id: barber.id,
              name: barber.name,
            })
          }
        />

        <TrustSection />

        <BookingFooter bookingRequest={bookingRequest} />
      </main>
    </>
  );
}