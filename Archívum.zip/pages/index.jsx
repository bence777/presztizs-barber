import Head from 'next/head';
import styles from '../styles/Home.module.css';
import HeroVideo from '../components/HeroVideo';
import BarberStack from "../components/BarberStack";
import Services from "../components/Services";
export default function Home() {
  return <>
    <Head><title>Presztízs Barber</title><meta name="description" content="Presztízs Barber — precíz vágások, karakteres stílus." /></Head>
    <main className={styles.site}>
      <header className={styles.header}>
        <a className={styles.brand} href="/">Presztízs <span>Barber</span></a>
        <nav aria-label="Fő navigáció"><a href="#munka">MUNKÁINK</a><a href="#rolunk">RÓLUNK</a><a href="#csapat">CSAPAT</a><a href="#foglalas">FOGLALÁS</a></nav>
      </header>
      <section className={styles.hero} aria-labelledby="hero-title">
        <HeroVideo />
        <div className={styles.portrait} aria-hidden="true" />
        <div className={styles.shade} aria-hidden="true" />
        <div className={styles.center}><h1 id="hero-title">PRESZTÍZS <em>Barber</em></h1><p>Minden vágásnak karaktere van</p></div>
        <div className={styles.bottomline}><span>SCROLL TO EXPLORE</span><a href="#foglalas">IDŐPONTFOGLALÁS</a></div>
      </section>
      <Services />
      <BarberStack />
    </main>
  </>;
}
