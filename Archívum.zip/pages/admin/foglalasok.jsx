import Head from 'next/head';
import AdminIdentityGate from '../../components/AdminIdentityGate';
import AdminDashboard from '../../components/AdminDashboard';
export default function AdminBookings(){
  return <><Head><title>Foglaláskezelő · DEMETERS</title><meta name="robots" content="noindex,nofollow,noarchive"/></Head>
    <div style={{minHeight:'100svh',background:'#0b0b0b'}}>
      <AdminIdentityGate><AdminDashboard/></AdminIdentityGate>
    </div>
  </>;
}
