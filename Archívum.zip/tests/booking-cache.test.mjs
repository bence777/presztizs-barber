import test from 'node:test';
import assert from 'node:assert/strict';
import { availabilityKey, getCachedAvailability, invalidateCachedAvailability, loadPublicCatalog, loadPublicAvailability } from '../lib/client/bookingCache.mjs';

const initialFetch = globalThis.fetch;
let calls = [];
globalThis.fetch = async (url,options={}) => {
  calls.push({url:String(url),options});
  if (String(url).includes('/config')) return { ok:true, json:async()=>({services:[{id:'hajvagas'}],barbers:[{id:'barber-1',name:'Paliga Zoltán'},{id:'legacy-1',name:'Első Barber'}]}) };
  return { ok:true, json:async()=>({days:{'2026-11-12':[{value:'11:00',available:true}]},hasWorkingHours:true}) };
};

test('Public catalog deduplicates concurrent requests and reloads changed metadata',async()=>{
  const [a,b] = await Promise.all([loadPublicCatalog(),loadPublicCatalog()]);
  assert.deepEqual(a,b);
  assert.deepEqual(a.barbers.map(member=>member.id),['barber-1']);
  await loadPublicCatalog();
  assert.equal(calls.filter(x=>x.url.includes('/config')).length,2);
  assert.equal(calls[0].options.credentials,'omit');
});

test('Availability deduplicates concurrent requests but never reuses stale slots',async()=>{
  const key = availabilityKey('hajvagas','barber-1','2026-11');
  assert.equal(key,'hajvagas|barber-1|2026-11');
  const [a,b] = await Promise.all([loadPublicAvailability('hajvagas','barber-1','2026-11'),loadPublicAvailability('hajvagas','barber-1','2026-11')]);
  assert.deepEqual(a,b);
  assert.equal(getCachedAvailability('hajvagas','barber-1','2026-11'),null);
  assert.equal(calls.filter(x=>x.url.includes('/availability')).length,1);
  invalidateCachedAvailability('hajvagas','barber-1','2026-11');
  assert.equal(getCachedAvailability('hajvagas','barber-1','2026-11'),null);
  await loadPublicAvailability('hajvagas','barber-1','2026-11', {force:true});
  assert.equal(calls.filter(x=>x.url.includes('/availability')).length,2);
  assert.match(calls.at(-1).url,/refresh=/);
  globalThis.fetch = initialFetch;
});
