# Presztízs Barber — Editorial concept

Next.js Pages Router, custom CSS. Inspired by the editorial composition of Halden and the service structure of Stropwell, not a direct clone.

## Run

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Notes

- Images load from Unsplash URLs and are temporary editorial placeholders; replace with licensed salon photography before launch.
- Services, durations, barber names and contact details are placeholders.
- Booking is deliberately disabled until a real booking integration is implemented. No fake success states.
